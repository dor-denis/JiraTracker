Automatically logs development time to Jira based on Git checkout history. See the documentation at https://github.com/dor-denis/JiraTracker


